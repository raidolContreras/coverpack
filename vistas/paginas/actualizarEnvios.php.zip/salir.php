<?php

session_destroy();

echo '<script>window.location = "?pagina=ingreso";</script>';